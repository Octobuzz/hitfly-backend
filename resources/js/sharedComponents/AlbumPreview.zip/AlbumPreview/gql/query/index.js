export { default as ALBUM } from 'gql/query/Album.graphql';
